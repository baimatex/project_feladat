<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('link1');
});


Route::get('/motorok', function () {
    return view('motorok'); // motorok oldal
});

Route::get('/rolunk', function () {
    return view('rolunk'); // Kapcsolat oldal
});

Route::get('/helyszin', function () {
    return view('helyszin'); // Helyszín oldal
});