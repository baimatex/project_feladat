<?php session_start(); // Session indítása ?>
<!DOCTYPE html>
<html lang="hu">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>

    <link rel="shortcut icon" href="../public/img/logo.png" type="image/x-icon">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- My CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/main_style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/motorok_style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/rolunk_style.css')); ?>">


    <!-- Fontawesome -->
    <script src="https://kit.fontawesome.com/b6c65a6a0f.js" crossorigin="anonymous"></script>

    <!-- Bootstrap Icon-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


</head>

<body>
    <!--                    Header                       -->
    <header id="header">
        <nav class="navbar bg-body-tertiary fixed-top" data-bs-theme="dark">
            <div class="container-fluid">
                <div class="d-flex">
                    <a class="navbar-brand" href="#">
                        <img src="kepek/kep.jpg" alt="" width="80" height="40">
                    </a>
                    <?php if (isset($_SESSION['FelhasznaloNev'])) { ?>
                        <h2 style="color:red; padding-top:5px;"><?php echo $_SESSION['FelhasznaloNev'] ?></h2>
                    <?php } else { ?>
                        <h2 style="color:white; padding-top:5px;"></h2>
                    <?php } ?>
                </div>
                <button class="navbar-toggler border border-0" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="offcanvas offcanvas-end menu" tabindex="-1" id="offcanvasNavbar"
                    aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasNavbarLabel">Menü</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="<?php echo e(url('/')); ?>">Főoldal</a>
                            </li>
                            <li class="nav-item dropdown mb-2">
                                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                                    aria-expanded="false">
                                    Dropdown
                                </a>
                                <ul class="dropdown-menu">
                                    <li class="mb-1"><a class="dropdown-item" href="<?php echo e(url('/motorok')); ?>">Motorok</a>
                                    </li>
                                    <hr id="hhr">
                                    <li><a class="dropdown-item" href="<?php echo e(url('/helyszin')); ?>">Helyszínek</a></li>
                                </ul>
                            </li>
                            <?php if (!isset($_SESSION['FelhasznaloNev'])) {
                                echo '
                            <li class="nav-item">
                                <a class="nav-link" a href="#" data-bs-toggle="modal" data-bs-target="#loginModal" data-bs-dismiss="modal">Belépés</a>
                            </li>';
                            } else {
                                echo
                                    '
                                <a class="nav-link" a href="../control/logout.php">Kijelentkezés</a>';
                            }
                            ?>

                            <li class="nav-item">
                                <a class="nav-link pt-0" href="#" data-bs-toggle="modal" data-bs-target="#registerModal"
                                    data-bs-dismiss="modal">Regisztrálás</a>
                            </li>

                            <hr class="mb-1">

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(url('/rolunk')); ?>">Rólunk</a>
                            </li>
                        </ul>

                    </div>
                </div>
            </div>
        </nav>
    </header>
    <!--                    /Header                       -->

    <!-- Login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Bejelentkezés</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="../control/login.php" method="POST">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" name="Email" id="Email" required>
                        </div>
                        <label for="JelszoLogin" class="form-label">Jelszó</label>
                        <div class="input-group">
                                <input type="Password" class="form-control" id="JelszoLogin" name="JelszoLogin" required>
                                <button class="btn btn-outline-secondary" type="button" id="toggleLoginPassword"
                                    style="border-radius: 0 5px 5px 0;">
                                    <i class="bi bi-eye-slash" id="eyeIcon"></i>
                                </button>
                        </div>
                        <br>

                        <script>
                            const toggleLoginPassword = document.getElementById('toggleLoginPassword');
                            const passwordLoginField = document.getElementById('JelszoLogin');

                            toggleLoginPassword.addEventListener('click', function () {
                                const type = passwordLoginField.type === 'password' ? 'text' : 'password';
                                passwordLoginField.type = type;


                                eyeIcon.classList.toggle('bi-eye');
                                eyeIcon.classList.toggle('bi-eye-slash');
                            });
                        </script>

                        <button name="submit" class="btn btn-primary">Bejelentkezés</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <a href="#" data-bs-toggle="modal" data-bs-target="#registerModal" data-bs-dismiss="modal">Nincs még
                        fiókja? Regisztráció</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Registration Modal -->
    <div class="modal fade" id="registerModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Regisztráció</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form action="../control/regiszt.php" method="POST">
                        <div class="mb-3">
                            <label for="Nev" class="form-label">Név</label>
                            <input type="text" class="form-control" id="Nev" name="Nev" required>
                        </div>
                        <div class="mb-3">
                            <label for="FelhasznaloNev" class="form-label">Felhasználónév</label>
                            <input type="text" class="form-control" id="FelhasznaloNev" name="FelhasznaloNev" required>
                        </div>
                        <div class="mb-3">
                            <label for="RegEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="RegEmail" name="RegEmail" required>
                        </div>
                        <div class="mb-3">
                            <div id="atError" class="form-text text-danger" style="display: none;">
                                Az email címnek tartalmaznia kell '@' karaktert.
                            </div>
                            <div id="domainError" class="form-text text-danger" style="display: none;">
                                Az email címnek '.com' vagy '.hu' végződéssel kell rendelkeznie.
                            </div>
                        </div>

                        <script>

                            const emailInput = document.getElementById('RegEmail');
                            const atError = document.getElementById('atError');
                            const domainError = document.getElementById('domainError');

                            emailInput.addEventListener("input", validateEmail);

                            function validateEmail() {
                                const emailValue = emailInput.value;
                                const submitBtn = document.getElementById('submitBtn');


                                emailInput.style.borderColor = "";

                                if (!emailValue.includes('@')) {
                                    atError.style.display = 'block';
                                    emailInput.style.borderColor = "red";
                                    submitBtn.disabled = true;
                                } else {
                                    atError.style.display = 'none';
                                }

                                if (!emailValue.endsWith('.com') && !emailValue.endsWith('.hu')) {
                                    domainError.style.display = 'block';
                                    emailInput.style.borderColor = "red";
                                    submitBtn.disabled = true;
                                } else {
                                    domainError.style.display = 'none';
                                }

                                if (emailValue.includes('@') && (emailValue.endsWith('.com') || emailValue.endsWith('.hu'))) {
                                    submitBtn.disabled = false;
                                }
                            }
                        </script>

                        <div class="mb-3">
                            <label for="Jelszo" class="form-label">Jelszó</label>
                            <div class="input-group">
                                <input type="Password" class="form-control" id="Jelszó" name="Jelszó" required>
                                <button class="btn btn-outline-secondary" type="button" id="togglePassword"
                                    style="border-radius: 0 5px 5px 0;">
                                    <i class="bi bi-eye-slash" id="eyeIcon"></i>
                                </button>
                            </div>
                            <div class="strength-bar">
                                <div class="bar" id="strength-bar"></div>
                            </div>
                            <small id="strength-text"></small>
                        </div>

                        <div class="mb-3">
                            <label for="JelszoSubmit" class="form-label">Jelszó Mégegyszer</label>
                            <input type="Password" class="form-control" id="JelszóSubmit" name="JelszóSubmit" required>
                            <small id="strength-text"></small>
                        </div>
                        <div class="mb-4">
                            <div id="passError" class="form-text text-danger" style="display: none;">
                                <h6>A két jelszó nem eggyezik!</h6>
                            </div>
                        </div>

                        <script>

                            const togglePassword = document.getElementById('togglePassword');
                            const eyeIcon = document.getElementById('eyeIcon');

                            togglePassword.addEventListener('click', function () {
                                const type = passwordField.type === 'password' ? 'text' : 'password';
                                passwordField.type = type;


                                eyeIcon.classList.toggle('bi-eye');
                                eyeIcon.classList.toggle('bi-eye-slash');
                            });


                            const passwordField = document.getElementById("Jelszó");
                            const passwordAgainField = document.getElementById("JelszóSubmit");
                            const passError = document.getElementById("passError");

                            passwordField.addEventListener("input", validatePasswords);
                            passwordAgainField.addEventListener("input", validatePasswords);

                            function validatePasswords() {
                                const submitBtn = document.getElementById("submitBtn");


                                passwordField.style.borderColor = "";
                                passwordAgainField.style.borderColor = "";

                                if (passwordField.value && passwordField.value === passwordAgainField.value) {
                                    passError.style.display = "none";
                                    passwordField.style.borderColor = "";
                                    passwordAgainField.style.borderColor = "";
                                    submitBtn.disabled = false;
                                } else {
                                    passError.style.display = "block";
                                    passwordField.style.borderColor = "red";
                                    passwordAgainField.style.borderColor = "red";
                                    submitBtn.disabled = true;
                                }
                            }


                            passwordField.addEventListener("input", () => {
                                const passwordValue = passwordField.value;
                                const strength = getPasswordStrength(passwordValue);
                                updateStrengthBar(strength);
                            });

                            function getPasswordStrength(password) {
                                let strength = 0;
                                if (password.length >= 6) strength++;
                                if (/[A-Z]/.test(password)) strength++;
                                if (/[a-z]/.test(password)) strength++;
                                if (/[0-9]/.test(password)) strength++;
                                if (/[^A-Za-z0-9]/.test(password)) strength++;
                                return strength;
                            }

                            function updateStrengthBar(strength) {
                                const strengthBar = document.getElementById("strength-bar");
                                const strengthText = document.getElementById("strength-text");

                                switch (strength) {
                                    case 0:
                                    case 1:
                                        strengthBar.className = "bar weak";
                                        strengthText.textContent = "Gyenge a jelszó";
                                        break;
                                    case 2:
                                    case 3:
                                        strengthBar.className = "bar medium";
                                        strengthText.textContent = "Közepes a jelszó";
                                        break;
                                    case 4:
                                    case 5:
                                        strengthBar.className = "bar strong";
                                        strengthText.textContent = "Erős a jelszó";
                                        break;
                                    default:
                                        strengthBar.className = "bar";
                                        strengthText.textContent = "";
                                }
                            }
                        </script>


                        <div class="mb-3">
                            <label for="Telefonszam" class="form-label">Telefonszám</label>
                            <input type="text" class="form-control" id="Telefonszam" name="Telefonszam" required>
                        </div>

                        <script>

                            const phoneInput = document.getElementById("Telefonszam");
                            phoneInput.addEventListener("input", () => {
                                const phoneValue = phoneInput.value;
                                const submitBtn = document.getElementById("submitBtn");


                                phoneInput.style.borderColor = "";

                                if (!/^\d{11}$/.test(phoneValue)) {
                                    phoneInput.style.borderColor = "red";
                                    submitBtn.disabled = true;
                                } else {
                                    submitBtn.disabled = false;
                                }
                            });
                        </script>

                        <div class="mb-3">
                            <label for="Jogositvany" class="form-label">Jogosítvány</label>
                            <select class="form-control" id="Jogositvany" name="Jogositvany" required>
                                <option value="" disabled selected>Válasszon jogosítvány típust</option>
                                <option value="AM">AM</option>
                                <option value="A1">A1</option>
                                <option value="A2">A2</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                            </select>
                        </div>
                        <button id="submitBtn" name="submit" class="btn btn-primary" disabled>Regisztráció</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php echo $__env->yieldContent('content'); ?><?php /**PATH C:\Users\Bai Máté\Desktop\Projekt_feladat\projekt_munka\resources\views/header.blade.php ENDPATH**/ ?>