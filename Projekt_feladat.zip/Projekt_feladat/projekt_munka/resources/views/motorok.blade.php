

<!--
Javitásra szorul:
- Elektromos üzemanyak kimaradt + rádió gomb helyett check box
- kártyák között nagy a hely
- ha kijelölöm a szűrésben akkor ha ujra megnyitom akkor látszódik mit írtam/jelöltem be
- restponzivitás telefonra
-->






<?php

/*
$query;
if (isset($_GET['Marka']) && isset($_GET['Kor']) && isset($_GET['Sebessegvalto']) && isset($_GET['Uzemanyag'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '" AND Kor ="' . $_GET["Kor"] . '" AND Sebessegvalto ="' . $_GET["Sebessegvalto"] . '" AND Uzemanyag ="' . $_GET["Uzemanyag"] . '";';
} else if (isset($_GET['Marka']) && isset($_GET['Kor']) && isset($_GET['Sebessegvalto'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '" AND Kor ="' . $_GET["Kor"] . '" AND Sebessegvalto ="' . $_GET["Sebessegvalto"] . '";';
} else if (isset($_GET['Marka']) && isset($_GET['Kor']) && isset($_GET['Uzemanyag'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '" AND Kor ="' . $_GET["Kor"] . '" AND Uzemanyag ="' . $_GET["Uzemanyag"] . '";';
} else if (isset($_GET['Kor']) && isset($_GET['Sebessegvalto']) && isset($_GET['Uzemanyag'])) {
  $query = 'SELECT * FROM motordata WHERE Kor ="' . $_GET["Kor"] . '" AND Sebessegvalto ="' . $_GET["Sebessegvalto"] . '" AND Uzemanyag ="' . $_GET["Uzemanyag"] . '";';
} else if (isset($_GET['Marka']) && isset($_GET['Sebessegvalto']) && isset($_GET['Uzemanyag'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '" AND Sebessegvalto ="' . $_GET["Sebessegvalto"] . '" AND Uzemanyag ="' . $_GET["Uzemanyag"] . '";';
} else if (isset($_GET['Marka']) && isset($_GET['Sebessegvalto'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '" AND Sebessegvalto ="' . $_GET["Sebessegvalto"] . '";';
} else if (isset($_GET['Kor']) && isset($_GET['Sebessegvalto'])) {
  $query = 'SELECT * FROM motordata WHERE Kor ="' . $_GET["Kor"] . '" AND Sebessegvalto ="' . $_GET["Sebessegvalto"] . '";';
} else if (isset($_GET['Marka']) && isset($_GET['Kor'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '" AND Kor ="' . $_GET["Kor"] . '";';
} else if (isset($_GET['Marka']) && isset($_GET['Uzemanyag'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '" AND Uzemanyag ="' . $_GET["Uzemanyag"] . '";';
} else if (isset($_GET['Kor']) && isset($_GET['Uzemanyag'])) {
  $query = 'SELECT * FROM motordata WHERE Kor ="' . $_GET["Kor"] . '" AND Uzemanyag ="' . $_GET["Uzemanyag"] . '";';
} else if (isset($_GET['Uzemanyag']) && isset($_GET['Sebessegvalto'])) {
  $query = 'SELECT * FROM motordata WHERE Uzemanyag ="' . $_GET["Uzemanyag"] . '" AND Sebessegvalto ="' . $_GET["Sebessegvalto"] . '";';
} else if (isset($_GET['Marka'])) {
  $query = 'SELECT * FROM motordata WHERE Marka ="' . $_GET["Marka"] . '";';
} else if (isset($_GET['Kor'])) {
  $query = 'SELECT * FROM motordata WHERE Kor ="' . $_GET["Kor"] . '";';
} else if (isset($_GET['Sebessegvalto'])) {
  $query = 'SELECT * FROM motordata WHERE Sebessegvalto ="' . $_GET["Sebessegvalto"] . '";';
} else if (isset($_GET['Uzemanyag'])) {
  $query = 'SELECT * FROM motordata WHERE Uzemanyag ="' . $_GET["Uzemanyag"] . '";';
} else {
  $query = 'SELECT * FROM motordata';
}
$result = mysqli_query($connection, $query);

$markaQuery = "SELECT DISTINCT Marka FROM motordata";
$markaResult = mysqli_query($connection, $markaQuery);
$korQuery = "SELECT DISTINCT Kor FROM motordata ORDER BY Kor ASC";
$korResult = mysqli_query($connection, $korQuery);
$valtoQuery = "SELECT 'Automata' AS Sebessegvalto UNION SELECT DISTINCT Sebessegvalto FROM motordata WHERE Sebessegvalto <> 'automata';";
$valtoResult = mysqli_query($connection, $valtoQuery);
*/

// Alap SQL lekérdezés
$query = "SELECT * FROM motordata";

// Feltételek gyűjtése
$conditions = [];

// A GET paraméterek ellenőrzése
if (isset($_GET['Marka'])) {
  $conditions[] = 'Marka = "' . $_GET['Marka'] . '"';
}
if (isset($_GET['Kor'])) {
  $conditions[] = 'Kor = "' . $_GET['Kor'] . '"';
}
if (isset($_GET['Sebessegvalto'])) {
  $conditions[] = 'Sebessegvalto = "' . $_GET['Sebessegvalto'] . '"';
}
if (isset($_GET['Uzemanyag'])) {
  $conditions[] = 'Uzemanyag = "' . $_GET['Uzemanyag'] . '"';
}
if (isset($_GET['Helyszin'])) {
  $conditions[] = 'Helyszin LIKE "_' . $_GET['Helyszin'] . '%"';
}

// A WHERE feltételek összefűzése "AND"-del
if (!empty($conditions)) {
  $query .= " WHERE " . implode(" AND ", $conditions);
}

// Lekérdezés végrehajtása
$result = mysqli_query($connection, $query);

// Kiegészítő lekérdezések
$markaQuery = "SELECT DISTINCT Marka FROM motordata";
$markaResult = mysqli_query($connection, $markaQuery);

$helyQuery = "SELECT DISTINCT SUBSTRING(Helyszin, 2, 2) AS Helyszin FROM motordata ORDER BY Helyszin ASC";
$helyResult = mysqli_query($connection, $helyQuery);

$korQuery = "SELECT DISTINCT Kor FROM motordata ORDER BY Kor ASC";
$korResult = mysqli_query($connection, $korQuery);

$valtoQuery = "SELECT 'Automata' AS Sebessegvalto UNION SELECT DISTINCT Sebessegvalto FROM motordata WHERE Sebessegvalto <> 'automata'";
$valtoResult = mysqli_query($connection, $valtoQuery);

?>



<div class="mcontent">
  <h2 style="text-align: center;">Motorok</h2>
  <!-- Szűrés gomb az oldalmenü megnyitásához -->
  <button class="open-btn btn btn-primary mb-4" type="button" data-bs-toggle="offcanvas"
    data-bs-target="#offcanvasWithBothOptions" aria-controls="offcanvasWithBothOptions">Szűrés <i
      class="fa-solid fa-sliders"></i></button>

  <!-- Oldalsó navigációs menü szűréshez -->
  <div class="filter offcanvas offcanvas-start " data-bs-scroll="true" tabindex="-1" id="offcanvasWithBothOptions"
    aria-labelledby="offcanvasWithBothOptionsLabel">
    <div class="offcanvas-header">
      <h4 class="offcanvas-title" id="offcanvasWithBothOptionsLabel">Szűrés</h4>
      <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <form method="GET">
        <div class="row container-fluid">
          <div class="col-12 mb-2" id="fmargin">
            <select class="form-control" name="Marka" id="Marka">
              <option value="" disabled selected>Márka</option>
              <?php
              while ($row = mysqli_fetch_assoc($markaResult)) {
                echo '<option value="' . $row["Marka"] . '">' . $row["Marka"] . '</option>';
              }
              ?>
            </select>
          </div>
          <div class="col-12 mb-2">
            <select class="form-control" name="Helyszin" id="Helyszin">
              <option value="" disabled selected>Kerület</option>
              <?php
              while ($row = mysqli_fetch_assoc($helyResult)) {
                if ($row["Helyszin"] != null) {
                  if ($row["Helyszin"][0] == 0) {
                    echo '<option value="' . $row["Helyszin"] . '">' . substr($row["Helyszin"], 1) . '</option>';

                  } else {
                    echo '<option value="' . $row["Helyszin"] . '">' . $row["Helyszin"] . '</option>';
                  }
                }
              }
              ?>
            </select>
          </div>
          <div class="col-12 mb-2">
            <select class="form-control" name="Kor" id="Kor">
              <option value="" disabled selected>Kor</option>
              <?php
              while ($row = mysqli_fetch_assoc($korResult)) {
                echo '<option value="' . $row["Kor"] . '">' . $row["Kor"] . '</option>';
              }
              ?>
            </select>
          </div>
          <div class="col-12 mb-2">
            <select class="form-control" name="Sebessegvalto" id="Sebessegvalto">
              <option value="" disabled selected>Sebesség valtó</option>
              <?php
              while ($row = mysqli_fetch_assoc($valtoResult)) {
                echo '<option value="' . $row["Sebessegvalto"] . '">' . $row["Sebessegvalto"] . '</option>';
              }
              ?>
            </select>
          </div>
          <div id="radio" class="mt-1">
            <div class="col-3">
              <label class="ms-0" for="B">Benzin: </label>
              <input class="form-check-input" type="checkbox" name="Uzemanyag" id="B" value="Benzin">
              <label for="D">Disel: </label>
              <input class="form-check-input" type="checkbox" name="Uzemanyag" id="D" value="Diesel">
              <label for="E">Elektromos: </label>
              <input class="form-check-input" type="checkbox" name="Uzemanyag" id="E" value="Elektromos">
            </div>
          </div>
          <div class="col-12 mt-2">
            <button class="btn btn-secondary w-100">Szűrés</button>
          </div>
        </div>
      </form>
    </div>
  </div>
  <div class="row" id="margin">
    <?php
    while ($row = mysqli_fetch_assoc($result)) {
      if ($row["Helyszin"] != null) {
        echo '<div class="col-md-4 mb-4 d-flex justify-content-center">'; // 3 oszlop egy sorban közepes és nagyobb kijelzőkön
      echo '<div class="card" style="width: 18rem;">';
      echo '<img src="..." class="card-img-top" alt="...">';
      echo '<div class="card-body">';
      echo '    <h5 class="card-title"><span class="marka">' . $row["Marka"] . '</span>' . $row["Ar"] . ' Ft/nap</h5>';
      echo ' <ul class="list-group list-group-flush">';
      echo '     <li class="list-group-item">' . $row["Marka"] . ' ' . $row["Tipus"] . '</li>';
      echo '     <li class="list-group-item">' . $row["Teljesitmeny"] . ' </li>';
      echo '     <li class="list-group-item">' . $row["Sebessegvalto"] . '</li>';
      echo '     <li class="list-group-item">' . $row["Helyszin"] . '</li>';
      echo ' </ul>';
      echo ' <div class="card-body">';
      echo '     <a href="#" class="card-link">Részletek</a>';
      echo ' </div>';
      echo ' </div>';
      echo ' </div>';
      echo '</div>'; // Col div lezárása
      };
      
      
    }
    ?>
  </div>


@extends('footer')

@section('content')

@endsection
